<?php
$DB_USER="manideep";
$DB_PASSWORD="Manideep@123";
$DB_DATABASE="herrlich12";
$DB_HOST="localhost";

$conn = mysqli_connect($DB_HOST, $DB_USER, $DB_PASSWORD,$DB_DATABASE) or die('Error connecting to mysql');
// mysqli_select_db($DB_DATABASE);


?>